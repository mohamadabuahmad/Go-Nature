package controllers;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import Client.ChatClient;
import Client.ClientUI;
import Protocol.ClientMessage;
import Protocol.ServerMessage;
import entities.Order;
import entities.Park;

public class OrderCC {

    // Utility method to send messages to the server and get a response
    private static ServerMessage sendMessageToServer(String methodName, ArrayList<Object> parameters) {
        ClientMessage msg = new ClientMessage(methodName, parameters, parameters.size());
        ClientUI.chat.accept(msg);
        return ChatClient.messageRecievedFromServerEvents.get(methodName);
    }

    public static boolean checkOrderAvailibilty(Time time, Date date, int numOfVisitors, String parkName) {
        if (time.compareTo(new Time(19, 0, 0)) < 0 && time.compareTo(new Time(8, 0, 0)) > 0) {
            ArrayList<Object> parameters = new ArrayList<>();
            parameters.add(time);
            parameters.add(date);
            parameters.add(numOfVisitors);
            parameters.add(parkName);
            ServerMessage response = sendMessageToServer("checkAvailibility", parameters);
            return (boolean) response.getData();
        }
        return false;
    }

    public static boolean addOrder(Order order) {
        if (order.getOrderType().toString().startsWith("UNPLANNED") || 
            checkOrderAvailibilty(order.getVisitTime(), order.getVisitDate(), order.getNumOfVisitors(), order.getPark().getName())) {
            ArrayList<Object> parameters = new ArrayList<>();
            parameters.add(order);
            ServerMessage response = sendMessageToServer("addOrder", parameters);
            return (boolean) response.getData();
        }
        return false;
    }

    public static boolean confirmOrder(Order order) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(order);
        parameters.add("confirmed");
        return updateOrderStatus(parameters);
    }

    public static boolean cancelOrder(Order order) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(order);
        parameters.add("unconfirmed");
        return updateOrderStatus(parameters);
    }

    // Reusing the sendMessageToServer method for updating order status
    public static boolean updateOrderStatus(ArrayList<Object> parameters) {
        ServerMessage response = sendMessageToServer("updateOrderStatus", parameters);
        return (boolean) response.getData();
    }

    public static ArrayList<Timestamp> fetchAvailibleOrderDates(Time time, Date date, int numOfVisitors, String parkName) {
        ArrayList<Timestamp> availableDates = new ArrayList<>();
        
        // Check each hour within the park's operational hours (assuming 8:00 to 19:00)
        for (int hour = 8; hour <= 19; hour++) {
            Time checkTime = new Time(time.getTime());
            checkTime.setHours(hour);
            
            if (checkOrderAvailibilty(checkTime, date, numOfVisitors, parkName)) {
                // Add the timestamp to the list if the slot is available
                Timestamp timestamp = new Timestamp(date.getYear(), date.getMonth(), date.getDate(), hour, 0, 0, 0);
                availableDates.add(timestamp);
            }
        }
        
        // Optionally, check additional dates beyond the provided date
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        for (int i = 1; i <= 3; i++) { // Check the next 3 days as an example
            cal.add(Calendar.DATE, 1); // Increment the day by 1
            Date nextDate = new Date(cal.getTimeInMillis());
            
            if (checkOrderAvailibilty(time, nextDate, numOfVisitors, parkName)) {
                // If the original time on the next day is available, add to the list
                Timestamp timestamp = new Timestamp(cal.getTimeInMillis());
                timestamp.setHours(time.getHours());
                timestamp.setMinutes(time.getMinutes());
                timestamp.setSeconds(0);
                timestamp.setNanos(0);
                availableDates.add(timestamp);
            }
        }
        
        return availableDates;
    }

    public static ArrayList<Order> getAllOrderForTraveler(String idNumber) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(idNumber);
        ServerMessage response = sendMessageToServer("getAllOrdersForTraveler", parameters);
        return (ArrayList<Order>) response.getData();
    }

    public static ArrayList<Park> getAllParksforClient() {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(null); // If necessary, adjust according to the method requirement on the server side
        ServerMessage response = sendMessageToServer("getAllParksForClient", parameters);
        return (ArrayList<Park>) response.getData();
    }

}
