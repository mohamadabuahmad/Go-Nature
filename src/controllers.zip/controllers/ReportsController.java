package controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Client.ChatClient;
import Client.ClientUI;
import Protocol.ClientMessage;
import Protocol.ServerMessage;
import entities.ParameterChangeRequest;
import entities.ReportType;

public class ReportsController {

    private static Object sendRequestAndGetResponse(String methodName, ArrayList<Object> parameters) {
        ClientMessage message = new ClientMessage(methodName, parameters, parameters.size());
        ClientUI.chat.accept(message);
        ServerMessage response = ChatClient.messageRecievedFromServerEvents.get(methodName);

        if (response == null) {
            // Log error or handle it based on your application's requirements
            System.err.println("Error: No response received from server for method " + methodName);
            return null;
        }

        return response.getData();
    }

    public static String getReport(Date date, ReportType reportType, String ParkName) {
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(reportType.toString(), date, ParkName));
        Object response = sendRequestAndGetResponse("GetReport", parameters);
        return response != null ? (String) response : "";
    }

    public static void addReportToDB(ReportType reportType, Date date, List<String> list, String ParkName) {
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(reportType.toString(), date, new ArrayList<>(list), ParkName));
        sendRequestAndGetResponse("InsertReports", parameters);
    }

    public static boolean CheckReportExistInDB(ReportType reportType, Date date, String ParkName) {
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(reportType.toString(), date, ParkName));
        Object response = sendRequestAndGetResponse("IsReportExisted", parameters);
        return response != null && (boolean) response;
    }

    public static ArrayList<ParameterChangeRequest> GetAllRequests(String ParkName) {
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(ParkName));
        Object response = sendRequestAndGetResponse("getAllRequests", parameters);
        return response != null ? (ArrayList<ParameterChangeRequest>) response : new ArrayList<>();
    }
}
