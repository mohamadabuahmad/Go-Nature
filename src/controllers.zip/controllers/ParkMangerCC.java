package controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;

import Client.ChatClient;
import Client.ClientUI;
import Protocol.ClientMessage;
import Protocol.ServerMessage;
import entities.ParameterChangeRequest;
import entities.ReportType;
import entities.reportHelper;

public class ParkMangerCC {
    public static ArrayList<String> totalVisitorReport;
    public static ArrayList<reportHelper> usageReport;

    private static Object sendAndReceive(String methodName, ArrayList<Object> parameters) {
        ClientMessage msg = new ClientMessage(methodName, parameters, parameters.size());
        ClientUI.chat.accept(msg);
        ServerMessage response = ChatClient.messageRecievedFromServerEvents.get(methodName);
        return response.getData();
    }

    public static void createTotalVisitorReport(Date date, String ParkName) {
        ReportType reportType = ReportType.number_of_visitors_report;
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(reportType, date, ParkName));
        
        if (!ReportsController.CheckReportExistInDB(reportType, date, ParkName)) {
            ArrayList<Long> result = (ArrayList<Long>) sendAndReceive("MakeTotalVisitorsReport", parameters);
            
            ArrayList<String> parameterStrings = new ArrayList<>();
            result.forEach(val -> parameterStrings.add(val.toString()));
            
            totalVisitorReport = parameterStrings;
            ReportsController.addReportToDB(reportType, date, parameterStrings, ParkName);
        } else {
            String str = ReportsController.getReport(date, reportType, ParkName);
            totalVisitorReport = new ArrayList<>(Arrays.asList(str.split(" ")));
        }
    }

    public static void createUsageReport(Date date, String ParkName) {
        ReportType reportType = ReportType.Usags_Report;
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(reportType.toString(), date, ParkName));
        
        if (!ReportsController.CheckReportExistInDB(reportType, date, ParkName)) {
            ArrayList<reportHelper> report = (ArrayList<reportHelper>) sendAndReceive("createUsageReport", parameters);
            usageReport = report;
            
            // Convert reportHelper to String format for DB insertion
            ArrayList<String> data = new ArrayList<>();
            report.forEach(r -> {
                data.add(String.valueOf(r.getDate().getTime()));
                data.add(r.getRange());
            });
            ReportsController.addReportToDB(reportType, date, data, ParkName);
        } else {
            String str = ReportsController.getReport(date, reportType, ParkName);
            ArrayList<String> list = new ArrayList<>(Arrays.asList(str.split(" ")));
            ArrayList<reportHelper> reportHelpers = convertToReportHelpers(list);
            usageReport = reportHelpers;
        }
    }

    public static void setParameter(ParameterChangeRequest parameter, Date startDate) {
        ArrayList<Object> parameters = new ArrayList<>(Arrays.asList(startDate, parameter.getType().toString(), parameter.getPark().getName(), "waiting", parameter.getNewValue(), parameter.getSendDate()));
        sendAndReceive("InsertParameter", parameters);
    }

    public static ArrayList<Object> getParameter(String ParkName) {
        return (ArrayList<Object>) sendAndReceive("getParkMangerParameters", new ArrayList<>(Arrays.asList(ParkName)));
    }

    // Helper method to convert String list to reportHelpers for usage report
    private static ArrayList<reportHelper> convertToReportHelpers(ArrayList<String> list) {
        ArrayList<reportHelper> reportHelpers = new ArrayList<>();
        for (int i = 0; i < list.size(); i += 2) {
            reportHelpers.add(new reportHelper(new Date(Long.parseLong(list.get(i))), list.get(i + 1)));
        }
        return reportHelpers;
    }
}
