package controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import Client.ChatClient;
import Client.ClientUI;
import Protocol.ClientMessage;
import Protocol.ServerMessage;
import entities.ParameterChangeRequest;
import entities.ReportType;

public class DepartmentMangerCC {

    public static List<Integer> cancelReport;
    public static List<Integer> visitReport;

    /**
     * Creates or retrieves a cancellation report.
     *
     * @param date     The report date.
     * @param parkName The park name.
     */
    public static void createCancelReport(Date date, String parkName) {
        List<String> result = new ArrayList<>();
        ReportType reportType = ReportType.cancelled_order_report;

        if (!ReportsController.CheckReportExistInDB(reportType, date, parkName)) {
            ArrayList<Object> msg = new ArrayList<>(Arrays.asList(reportType.toString(), date, parkName));
            ClientMessage msg2 = new ClientMessage("MakeCancelReport", msg, 2);
            ClientUI.chat.accept(msg2);

            ServerMessage srMessage = ChatClient.messageRecievedFromServerEvents.get(msg2.getMethodName());
            cancelReport = (ArrayList<Integer>) srMessage.getData();
            result.add(String.valueOf(cancelReport.get(0)));
            result.add(String.valueOf(cancelReport.get(1)));
            
            ReportsController.addReportToDB(reportType, date, result, parkName);
        } else {
            displayReportFromDB(date, parkName, reportType);
        }
    }

    /**
     * Creates or retrieves a visit report.
     *
     * @param date     The report date.
     * @param parkName The park name.
     */
    public static void createVisitReport(Date date, String parkName) {
        if (!ReportsController.CheckReportExistInDB(ReportType.Visits_Report, date, parkName)) {
        	ArrayList<Object> msg = new ArrayList<>(Arrays.asList(date, parkName));
        	ClientMessage msg2 = new ClientMessage("makeVisitReport", msg, 3);
            ClientUI.chat.accept(msg2);
            ServerMessage srMessage = ChatClient.messageRecievedFromServerEvents.get(msg2.getMethodName());
            visitReport = (ArrayList<Integer>) srMessage.getData();

            List<String> data = convertToStringList(visitReport);
            ReportsController.addReportToDB(ReportType.Visits_Report, date, data, parkName);
        } else {
            displayReportFromDB(date, parkName, ReportType.Visits_Report);
        }
    } 

    /**
     * Confirms a parameter change request.
     *
     * @param parameter The parameter change request.
     * @param startDate The start date for the parameter change.
     * @param value     The new value for the parameter.
     */
    public static void confirmParameter(ParameterChangeRequest parameter, Date startDate, Object value) {
        updateParameter("confirmed", parameter, startDate, value);
    }

    /**
     * Unconfirms a parameter change request.
     *
     * @param parameter The parameter change request.
     * @param startDate The start date for the parameter change.
     * @param value     The value associated with the unconfirmation.
     */
    public static void unconfirmParameter(ParameterChangeRequest parameter, Date startDate, Object value) {
        updateParameter("unconfirmed", parameter, startDate, value);
    }

    private static void updateParameter(String status, ParameterChangeRequest parameter, Date startDate, Object value) {
        ArrayList<Object> msg = new ArrayList<>(Arrays.asList(status, startDate, parameter.getType().toString(), parameter.getPark().getName(), "waiting", value));
        System.out.println("Sending message to server: " + msg); // Debugging line
        ClientMessage msg2 = new ClientMessage("UpdateParameter", msg, 6);
        ClientUI.chat.accept(msg2);
    }

    private static void displayReportFromDB(Date date, String parkName, ReportType reportType) {
        String str = ReportsController.getReport(date, reportType, parkName);
        System.out.println(str);
        List<Integer> report = convertToIntegerList(str.split(" "));
        if (ReportType.cancelled_order_report.equals(reportType)) {
            cancelReport = new ArrayList<>(report);
        } else if (ReportType.Visits_Report.equals(reportType)) {
            visitReport = new ArrayList<>(report);
        }
    }

    private static List<String> convertToStringList(List<Integer> report) {
        List<String> data = new ArrayList<>();
        report.forEach(num -> data.add(String.valueOf(num)));
        return data;
    }

    private static List<Integer> convertToIntegerList(String[] data) {
        return Arrays.stream(data)
                     .map(Integer::valueOf)
                     .collect(Collectors.toList());
    }

}
