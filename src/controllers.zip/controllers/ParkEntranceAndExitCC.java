package controllers;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import Client.ChatClient;
import Client.ClientUI;
import Protocol.ClientMessage;
import Protocol.ServerMessage;
import entities.Order;
import entities.Park;

public class ParkEntranceAndExitCC {

    // Unified method to send requests to the server and receive responses.
    private static Object sendRequest(String methodName, ArrayList<Object> parameters) {
        ClientMessage msg = new ClientMessage(methodName, parameters, parameters.size());
        ClientUI.chat.accept(msg);
        ServerMessage response = ChatClient.messageRecievedFromServerEvents.get(methodName);
        return response.getData();
    }

    public static boolean identifyAtEntrance(String identifyNumber, String parkName) {
        Order order = identify(identifyNumber, parkName);
        if (order == null) return false;
        
        updateNumberOfVisitors(order, true); // true for entrance
        updateArrivalStatus(order, true); // true for updating entrance time
        return true;
    }

    public static boolean identifyAtExit(String identifyNumber, String parkName) {
        Order order = identify(identifyNumber, parkName);
        if (order == null) return false;
        
        order.setNumOfVisitors(-1 * order.getNumOfVisitors()); // Negate the visitors count for exit
        updateNumberOfVisitors(order, false); // false for exit
        updateArrivalStatus(order, false); // false for updating exit time
        return true;
    }

    // Method to identify the order with the given identifyNumber and parkName
    public static Order identify(String identifyNumber, String parkName) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(identifyNumber);
        parameters.add(Date.valueOf(LocalDate.now()));
        parameters.add(Time.valueOf(LocalTime.now()));
        parameters.add(parkName);
        return (Order) sendRequest("searchOrder", parameters);
    }

    // Updates the number of visitors. The isEntrance flag determines if this is an entrance or exit update.
    private static void updateNumberOfVisitors(Order order, boolean isEntrance) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(order);
        String methodName = isEntrance ? "updateOrderArrivalStatus" : "updateOrderArrivalStatusOnExit";
        sendRequest(methodName, parameters);
    }

    // Updates the arrival status based on the isEntrance flag.
    private static void updateArrivalStatus(Order order, boolean isEntrance) {
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(order);
        String methodName = isEntrance ? "updateOrderArrivalStatus" : "updateOrderArrivalStatusOnExit";
        sendRequest(methodName, parameters);
    }
}
